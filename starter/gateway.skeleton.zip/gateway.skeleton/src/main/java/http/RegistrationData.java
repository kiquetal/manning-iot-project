package http;

public class RegistrationData {

}
